/** Latest update: July, 2014  by Aya Kuchiba **/



%macro subtype(
 data=,               /** data set on which data set on which the analysis is conducted **/

 studydesign=COHORT,  /** COHORT if cohort study, MCACO if matched or nested case-control study, CACO
 if case-control study, CACA if case-case study (the default value is COHORT) **/

 id=ID,               /** subject IDs; each subject may have multiple entries; required when
 studydesign=COHORT (the default value is ID) **/

 augmented=NO,        /** YES/NO; YES if the input dataset is augmented for every
 outcome subtype; applicable only if studydesign=COHORT (the default value is NO) **/

 exposure=,           /** the exposure variable or levels of an exposure variable; the subtype
heterogeneity test is for comparing coefficient(s) of this/these variable(s); the macro can
handle multiple exposure variables, which can be indicator variables for a categorical
exposure, which should be put in curly brackets,  or multiple exposures, for each of which
the heterogeneity test is performed; for a cohort study, if augmented=YES, the variable names
should have the suffix '_j' indicating subtypes (j=1,2,...,J total subtypes) and the variables
should be sorted by subtypes in curly brackets. For example, if you have two exposures, a 3-level
categorical exposure alcohol drinking, with indicators, alco2 and alco3, and another binary exposure
bmi (body mass index), and J=3, for augmented=YES, this macro parameter should be defined as
{alco2_1 alco3_1 alco2_2 alco3_2 alco2_3 alco3_3} {bmi_1 bmi_2 bmi_3}; if the data set is no augmented,
this macro parameter should be {alco2 alco3} bmi. **/

 time=,               /** time-to-failure variable; a single failure-time variable or end time variable of at-risk intervals
for the counting process format, used in the model statement of PROC PHREG; required if studydesign=COHORT;
otherwise not applicable. **/

 entrytime=,          /** entry time variable for time-to-failure variable; required if studydesign=COHORT and
the user specifies the at-risk intervals for the time variable used in the model statement of PROC PHREG;
if the user specifies a single failure-time variable, this parameter should be empty.
**/

 eventtype=,          /** subtype variable, required for all designs; for a cohort study,
if augmented=YES, the specified variable takes on the value j for all person-times for the
outcome subtype j (j=1,2,...,J total subtypes) and censoring status will be specified in the
parameter censoring; if augmented=NO, the variable specified has value j if the outcome subtype j has
occurred by end of follow up or 0 if censored; for a case-control or case-case study, the variable
has j for cases with outcome subtype j and 0 for controls (in case-control study) **/

 censoring=,          /**censoring variable. The variable takes on value 0 if censored and
1 if the corresponding outcome subtype contained in eventtype occurs; applicable only if augmented=YES **/

 unconstrvar=,        /**names of covariates, not including the exposure variables,
of which the associations with the outcome may be different for different outcome subtypes  (optional) **/

 constrvar=,          /** names of covariates, not including the exposure variables,
of which the associations with the outcome are forced to be the same across subtypes of outcome (optional) **/

 stratavar=,          /** stratification variables; only applicable if studydesign=COHORT, MCACO, or CACO with
 conditional=YES (optional) **/

 matchid=,            /** matched set variable code; applicable only if studydesign=MCACO **/

 reftype=1,           /** reference subtype variable code; applicable only if studydesign=CACA (the default value is 1) **/

 conditional=NO,      /** YES/NO; YES if requesting conditional logistic regression analysis for unmatched
 case-control study; this allows the constrained analysis and
 heterogeneity test by likelihood ratio test; applicable only if studydesign=CACO (the default value is NO) **/

 covs=NO,             /** YES/NO; YES if requesting the robust sandwich covariance matrix estimate; applicable
 only if studydesign=COHORT, MCACO, or CACO with conditional=YES (the default value is NO) **/

 wald=NO,             /** YES/NO; YES if requesting Wald test for the heterogeneity test, in addition to the default
 likelihood ratio test; only applicable if studydesign=COHORT, MCACO, or CACO with conditional=YES; Wald test is
 the only heterogeneity test available (and is the default test) for studydesign=CACA and CACO with conditional=NO (the
 default value is NO) **/

 covout=NO,           /** YES/NO; YES if requesting to display the estimated covariance matrix of the parameter estimates (the default value is NO)**/

 eventtypelabel=,     /** it can be used to define the coding of "eventtype"; please do not used ',' here;
for example, eventtypelabel= 1=high; 2=low; (optional)**/

 paramest=,           /** name of SAS dataset containing the parameter estimates (optional) **/

 heterotest=,         /** name of SAS dataset containing the results from the heterogeneity tests; if Wald test is
 requested with studydesign=COHORT, MCACO, or CACO with conditional=YES, those results are contained in the data
 set named "heterotest"_WT (optional)**/

 covest=              /** name of SAS dataset containing the estimated covariance matrix of the parameter estimates (optional)
 **/
    );


/***********************
    uses utility macros
    - numargs
 ***********************/
/*%include '/usr/local/channing/sasautos/numargs.sas';*/


%*                                                                            ;
%* This macro was developed by Carrie Wager,Programmer,Channing Laboratory 1990;
%* Modified AMcD 1993, e hertzmark 1994 and L Chen 1996;
%*                                                                            ;

%macro numargs(arg, delimit);
   %if %quote(&arg)= %then %do;
        0
   %end;
   %else %do;
     %let n=1;
     %do %until (%qscan(%quote(&arg), %eval(&n), %str( ))=%str()); 
        %let n=%eval(&n+1);
        %end;
	%eval(&n-1)
   %end;
   %mend numargs;




/* changing options for the macro run, but saving originals */
%let _fdl = %sysfunc(getoption(formdlim));
%let _nt  = %sysfunc(getoption(notes));

options nonotes obs=max formdlim='=' nosyntaxcheck;

*------------ make the parameters upper case ------------;
%let studydesign   = %upcase(&studydesign);
%let time          = %upcase(&time);
%let entrytime     = %upcase(&entrytime);
%let augmented     = %upcase(&augmented);
%let covs          = %upcase(&covs);
%let wald          = %upcase(&wald);
%let conditional   = %upcase(&conditional);
%let covout        = %upcase(&covout);

*------------ checking for required parameters ------------;
%if %length(&paramest) eq 0 %then %do; %let paramest=paramest; %end;
%if %length(&heterotest) eq 0 %then %do; %let heterotest=heterotest; %end;
%if %length(&covest) eq 0    %then %do; %let covest=covest; %end;
%if &augmented ne YES %then %let augmented=NO;


*----------- error to quit the macro----------;
*initialize macro variables;
%let dataerr=0;  %let experr=0; %let designerr=0; %let evtypeerr=0;
%let timeerr=0; %let iderr=0;  %let censerr=0; %let matcherr=0;

%if %length(&data)        eq 0 %then %do; %let dateerr=1;    %end;
%if %length(&exposure)    eq 0 %then %do; %let experr=1;     %end;
%if %length(&studydesign) eq 0 %then %do; %let designerr=1;  %end;
%if %length(&eventtype)   eq 0 %then %do; %let evtypeerr=1;  %end;

%if &studydesign=COHORT %then %do;
    %if %length(&time) eq 0       %then %do; %let timeerr=1; %end;
    %if %length(&id)         eq 0 %then %do; %let iderr=1; %end;
    %if &augmented=YES & %length(&censoring) eq 0 %then %do; %let censerr=1; %end;
%end;
%if &studydesign=MCACO %then %do;
    %if %length(&matchid) eq 0 %then %do; %let matcherr=1;   %end;
%end;

data _null_;
    dataerr=&dataerr; experr=&experr; designerr=&designerr; evtypeerr=&evtypeerr;
    timeerr=&timeerr; iderr=&iderr; censerr=&censerr; matcherr=&matcherr;
    _callerr=0;
    _callerr=max(dataerr, experr, designerr, evtypeerr, timeerr, iderr, censerr, matcherr);
   if _callerr eq 1 then do;
       if dataerr eq 1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a DATA set for the analysis.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a DATA set for the analysis.';
          end;
       if experr eq 1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give exposure variables in EXPOSURE.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give exposure variables in EXPOSURE.';
          end;
       if designerr=1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a study design in STUDYDESIGN.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a study design in STUDYDESIGN.';
          end;
       if evtypeerr=1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in EVENTTYPE.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in EVENTTYPE.';
          end;
       if timeerr=1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in TIME,
                  as required when you use studydesign=COHORT.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in TIME,
                  as required when you use studydesign=COHORT.';
          end;
       if iderr=1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in ID,
                  as required when you use studydesign=COHORT.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in ID,
                  as required when you use studydesign=COHORT.';
          end;
       if censerr=1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in CENSORING,';
           put '     as required when you use studydesign=COHORT and augmented=YES.';
           file print;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in CENSORING,';
           put '     as required when you use studydesign=COHORT and augmented=YES.';
          end;
       if matcherr=1 then do;
           put ' ';
           put 'ERR''OR in macro call:  You did not give a variable name in MATCHID,';
           put '     as required when you use studydesign=MCACO.';
           file print;
           put 'ERR''OR in macro call:  You did not give a variable name in MATCHID,';
           put '     as required when you use studydesign=MCACO.';
           end;
       end;
   call symput ('_callerr', _callerr);
run;

%if &_callerr eq 1 %then %goto qsubtype;

*---warning messages for inconsistency in required parameters;
%if &studydesign ne COHORT %then %do;
     %if %length(&time) ne 0 %then %do;
         data _null_;
            put "WARN''ING in macro call:  Your SUBTYPE call have a value for a TIME parameter,";
            put "   but you have requested a &studydesign study.";
            put "   The macro will continue, ignoring TIME=&time.";
            file print;
            put "WARN''ING in macro call:  your SUBTYPE call have a value for a TIME parameter,";
            put "   but you have requested a &studydesign study.";
            put "   The macro will continue, ignoring TIME=&time.";
         run;
         %end;
%end;

%if &augmented eq NO & %length(&censoring) ne 0 %then %do;
    %if &studydesign eq COHORT %then %do;
        data _null_;
            put "WARN''ING in macro call:  Your SUBTYPE call have a value for a CENSORING parameter,";
            put "   but you have requested a AUGMENTED=NO";
            put "   The macro will continue, ignoring CENSORING=&censoring.";
            file print;
            put "WARN''ING in macro call:  Your SUBTYPE call have a value for a CENSORING parameter,";
            put "   but you have requested a AUGMENTED=NO";
            put "   The macro will continue, ignoring CENSORING=&censoring.";
        run;
     %end;
%end;

%if &studydesign ne MCACO & %length(&matchid) ne 0 %then %do;
         data _null_;
             put "WARN''ING in macro call:  Your SUBTYPE call have a value for a MATCHID parameter,";
             put "   but you have requested a &studydesign study.";
             put "   The macro will continue, ignoring MATCHID=&matchid.";
             file print;
             put "WARN''ING in macro call:  Your SUBTYPE call have a value for a MATCHID parameter,";
             put "   but you have requested a &studydesign study.";
             put "   The macro will continue, ignoring MATCHID=&matchid.";
         run;
%end;

%if &studydesign eq CACO & &conditional eq NO & %length(&constrvar) ne 0 %then %do;
    data _null_;
        put "WARN''ING in macro call:  Your SUBTYPE call have a value for a CONSTRVAR parameter,";
        put "   but this model does not accept the constrained analysis.";
        put "   You may consider using CONDITIONAL=YES option.";
        put "   The macro will continue, not adjusting for &CONSTRVAR.";
        file print;
        put "WARN''ING in macro call:  Your SUBTYPE call have a value for a CONSTRVAR parameter,";
        put "   but this model does not accept the constrained analysis.";
        put "   You may consider using CONDITIONAL=YES option.";
        put "   The macro will continue, not adjusting for &CONSTRVAR.";
run;
%end;



/** get the number of outcometypes from &eventtype **/
 %let _ntype_=;

 proc sql noprint;
    select count(unique(&eventtype)) into :_ntype_ from &data;
 quit;

/*** individual macro names for exposures and unconstrained variables ***/


%if &augmented=NO %then %do;
/** get list of non-dummy variables and dummy variables separetely from &exposure **/
data _null_;
   /* delete dummy variables from  &exposure */
    exposureND=prxchange('s/\{.*?\}//m',-1,"&exposure");
    call symput("exposureND", exposureND);

   /* number of variables put by dummy variables */
    count=count(%quote("&exposure"),"}");
    call symput("_nexpD",count);

   /* pick up each dummy variable unit */
    exposureD=prxchange('s/.*?(\{.*?\})?/$1/m',-1,"&exposure");
    call symput ("exposureD",exposureD);
run;

 %let _nexpND=%numargs(&exposureND);
 %let _nexp=%eval(&_nexpD + &_nexpND);


%do i=1 %to &_nexpND;
   %let _expND_&i = %scan(&exposureND, &i, %str( ));
%end;
%do i=1 %to &_nexpD;
   %let _expD_&i = %scan(&exposureD, &i, %str({}));
   %let _nexpD_&i= %numargs(&&_expD_&i);
    %do j=1 %to &&_nexpD_&i;
   		%let _expD_&i._&j. = %scan(&&_expD_&i, &j, %str( ));
    %end;
%end;

data _null_;
    a=tranwrd("&exposureD", "{", " ");
    b=tranwrd(a, "}", " ");
    call symput ("exposureD_", b);  *list of all dummy variables;
run;

/** number of unconstrained variables **/
%let _nunconstrvar = %numargs(&unconstrvar);
%if &_nunconstrvar ne 0 %then %do;
    %do i=1 %to &_nunconstrvar;
             %let _ucv_&i = %scan(&unconstrvar, &i, %str( ));
    %end;
  %end;

%end;

%else %if &augmented=YES %then %do;
data _null_;
 count=count(%quote("&exposure"),"}");
 call symput("_nexp",count);
 exptmp=prxchange('s/.*?(\{.*?\})?/$1/m',-1,"&exposure");
 call symput("exptmp",exptmp);
run;
data _null_;
    a=tranwrd("&exptmp", "{", " ");
    b=tranwrd(a, "}", " ");
    call symput ("exposure_", b);  *list of all exposure variables;
run;

%let _nexpND=0;
%let _nexpD=0;

%do i=1 %to &_nexp;
  %let _exptmp_&i=%scan(&exptmp,&i,%str({}));
  %let _nexptmp_&i=%numargs(&&_exptmp_&i);

data _null_;
  flag=round(mod(&&_nexptmp_&i, &_ntype_));
  call symput ("mod",flag);
  run;

%if  &mod ne 0 %then %do;
  data _null_;
      put "ERR""OR in macro run:  invalid input in a EXPOSURE parameter.";
      put "The number of variables should be multiples of the number of outcome type.";
      put " ";
      file print;
      put "ERR""OR in macro run:  invalid input in a EXPOSURE parameter.";
      put "The number of variables should be multiples of the number of outcome type.";
      put " ";
run;
%end;
%if  &mod ne 0 %then %goto qsubtype;

%else %if &&_nexptmp_&i=&_ntype_ %then %do;
    %let _nexpND=%eval(&_nexpND+1);
    data _null_;
        tmp="%scan(&&_exptmp_&i,1,%str( ))";
        _expND_&_nexpND=kscan(tmp,1,"_");
        call symput ("_expND_&_nexpND", trim(left(_expND_&_nexpND)));
    run;

    %do j=1 %to &_ntype_;
	%let _expND_&_nexpND._&j=%scan(&&_exptmp_&i,&j,%str( ));
	%end;
%end;

%else %if &&_nexptmp_&i>&_ntype_ %then %do;
    %let _nexpD=%eval(&_nexpD+1);
    %let _nexpD_&_nexpD=%eval(&&_nexptmp_&i/&_ntype_);
    %do j=1 %to &_ntype_;
      %do m=1 %to &&_nexpD_&_nexpD..;
           data _null_;
             tmp="%scan(&&_exptmp_&i,&m,%str( ))";
             _expD_&_nexpD._&m=kscan(tmp,1,"_");
             call symput ("_expD_&_nexpD._&m", trim(left(_expD_&_nexpD._&m)));
            run;

	    %let _expD_&_nexpD._&m._&j=%scan(&&_exptmp_&i,%eval((&j-1)*(&&_nexpD_&_nexpD..)+&m),%str( ));
       %end;
     %end;
     data _null_;
         length tmp $64.;
         tmp=compress("&&_expD_&_nexpD._1.")  %do m=2 %to &&_nexpD_&_nexpD..; ||" "||compress("&&_expD_&_nexpD._&m..") %end; ;
         call symput("_expD_&_nexpD",tmp);
run;

    %end;

  %end;
%end;


/*------missing check for X ---*/
proc means data=&data. noprint;
    var
        %if "&studydesign" eq "COHORT"  %then %do; &id %end;
        %if "&studydesign" eq "COHORT"   %then %do; &time %end;
        %if "&augmented" eq "YES"        %then %do; &censoring %end;
        %if "&studydesign" eq "MCACO"    %then %do; &matchid %end;

       &eventtype  %if "&augmented" eq "NO" %then %do; &exposureND &exposureD_ %end;
                   %if "&augmented" eq "YES" %then %do; &exposure_ %end;
       &constrvar &unconstrvar &stratavar;
  output out=missingchk nmiss=;
run;

ods listing;
data missingchk;
    set missingchk;
    drop _TYPE_ _FREQ_;
run;

data missingchk1; set missingchk end=last;
 array allvar{*} _numeric_;
 _nonems_='1';
 do i=1 to dim(allvar);
     if allvar{i} gt 0 then do;
         put ' ';
         put 'WARN' 'ING in macro run: number of missing values for variable ' allvar{i}= ;
         _nonems_='0';
         end;
     end;
 if last then do;
     if _nonems_='0' then do;
         put ' ';
         put 'Data set in %subtype should have the same N for all variables.' ;
         put "Review the variables above in &data.";
       end;
     end;
run;

data missingchk1; set missingchk end=last;
 array allvar{*} _numeric_;
 _nonems_='1';
 file print;
 do i=1 to dim(allvar);
     if allvar{i} gt 0 then do;
         put ' ';
         put 'WARN' 'ING in macro run: number of missing values for variable ' allvar{i}= ;
         _nonems_='0';
         end;
     end;
 if last then do;
     if _nonems_='0' then do;
         put " ";

         put 'Data set in %subtype should have the same N for all variables.' ;
         put "Review the variables above in &data.";
       end;
     end;
run;


*get inappropriate matchids (sets with missing eventtype, or case/control only sets) to exclude those matched sets from analysis;
%if &studydesign eq MCACO %then %do;
/*check missings*/
data excset;
        set &data end=last;
        retain exc 0;
        if &eventtype eq . then do;  exc=exc+1; flag=1; end;
        else do; exc=exc; flag=0; end;
        if last then call symput('nexc',exc);
run;

%if &nexc > 0 %then %do;
    proc sort data=excset(where=(flag eq 1)) ;
        by &matchid;
    run;
    data excset;
        set excset;
        by &matchid;
        if first.&matchid;
        keep &matchid;
    run;
    data _null_;
        set excset nobs=nobs;
        call symput('nexcset', nobs);
    run;

    data &data; /*data set for the following analysis*/
        merge &data excset(in=a);
        by &matchid;
        if a then delete;
    run;

    proc transpose data=excset out=excset;
    run;

    data _null_;
        set excset;
        excmid=compress(col1 %if &nexcset gt 1 %then %do;
            %do i=2 %to &nexcset; ||','|| col&i. %end; %end;
                );
        put "WARN' 'ING in macro run: There are &nexcset matched sets with missing values in &eventtype";
        put "&matchid = " excmid;
        put "   will be excluded from a data set used in analysis.";
        put " ";

        file print;
        put "WARN' 'ING in macro run: There are &nexcset matched sets with missing values in &eventtype";
        put "&matchid = " excmid;
        put "   will be excluded from a data set used in analysis.";
        put " ";
    run;
%end;

/*check case/control only sets*/
proc sort data=&data;
    by &matchid;
run;

data excset2;
 set &data;
 if &eventtype gt 0 then _eventtypetmp_=1;
 else _eventtypetmp_=&eventtype;
run;

proc sort data=excset2;
    by &matchid _eventtypetmp_;
run;

data excset2;
    set excset2 end=last;
    retain nnn 0 nn 0 _flag 0;
    by &matchid _eventtypetmp_;
    if first._eventtypetmp_ then nnn=1;
    else nnn=nnn+1;
    if first.&matchid then nn=1;
    else nn=nn+1;
    if last.&matchid;
    if nnn=nn then _flag=_flag+1;
    else _flag=_flag;
    if last then call symput('nexcset2',_flag);
    if nnn=nn;
    keep &matchid;
run;

%if &nexcset2 > 0 %then %do;
    data &data; /*data set for the following analysis*/
        merge &data excset2(in=a);
        by &matchid;
        if a then delete;
run;

proc transpose data=excset2 out=excset2;
run;

   data _null_;
        set excset2;
        excmid=compress(col1 %if &nexcset2 gt 1 %then %do;
            %do i=2 %to &nexcset2; ||','|| col&i. %end; %end;
                );
        put "WARN' 'ING in macro run: There are &nexcset2 matched sets with control or case only";
        put "&matchid = " excmid;
        put "   will be excluded from a data set used in analysis.";
        put " ";

        file print;
        put "WARN' 'ING in macro run: There are &nexcset2 matched sets with control or case only";
        put "&matchid = " excmid;
        put "   will be excluded from a data set used in analysis.";
        put " ";
    run;

%end;

%end;



ods listing close;


*-------------- PROC PHREG (cohort study, matched case-control study and optional unmatced case-control study) --------------------------;
%if &studydesign eq COHORT | &studydesign eq MCACO | (&studydesign eq CACO & &conditional eq YES) %then %do;

*-------------- data re-format;
%if &studydesign=COHORT %then %do;
    %if &augmented=NO %then %do;
        data _tmp_;
            set &data;
        	time=&time;
                %if %length(&entrytime) eq 0 %then %do; entrytime=0; %end;
                                             %else %do; entrytime=&entrytime; %end;
                do i=1 to %eval(&_ntype_-1); ** assume 0 is for censored **;
                outcometype=i;
                censoring=0;
                if &eventtype = i then censoring=1;
                output;
                end;
         run;
        %end;
    %else %if &augmented=YES %then %do;
        data _tmp_;
            set &data;
	    time=&time;
                %if %length(&entrytime) eq 0 %then %do; entrytime=0; %end;
                                             %else %do; entrytime=&entrytime; %end;
            outcometype=&eventtype;
            censoring=&censoring;
        run;
        %end;
    %end;

%else %if &studydesign=MCACO %then %do;
    proc sort data=&data;
        by &matchid descending &eventtype;
    run;
    data _tmp_;
        set &data;
        if &eventtype=0 then do; censoring=0; time=2; end;
        else do; censoring=1; time=1; end;
        entrytime=0;
        retain outcometype 0;
        by &matchid;
        if first.&matchid then outcometype=&eventtype;
        else outcometype=outcometype;
    run;

%end;

%else %if (&studydesign eq CACO) & (&conditional eq YES) %then %do;
     data _tmp_;
            set &data;
                do i=1 to %eval(&_ntype_-1); ** assume 0 is for censored **;
                outcometype=i;
                censoring=0;
                time=2;
                entrytime=0;
                if &eventtype = i then do; censoring=1; time=1; end;
                output;
                end;

         run;
         data _tmp_;
             set _tmp_;
             if &eventtype=outcometype | &eventtype=0 then output;
run;

%end;


    /* get list of values of outcometype */
     proc sort data=_tmp_;  by outcometype;  run;
     proc means noprint data=_tmp_;  var outcometype;
         output  out=_expblist_  mean=m_outcometype;
         by outcometype;
         where outcometype ne . ;
     run;

     data _expblist_;
        set _expblist_  end=_end_;
        call symput('_eb_'||trim(left(_n_)), trim(left(m_outcometype)));
        if _end_ then call symput ('_neb_', trim(left(_n_)));
      run;


%if &augmented=NO %then %do;
   data newdatname;
       set _tmp_;
       where time ne .  and censoring ne . and outcometype ne . ;

       %do i=1 %to &_neb_;
          %do j=1 %to &_nunconstrvar;
             _ucv_&j._&i=&&_ucv_&j*(outcometype=&&_eb_&i);
          label _ucv_&j._&i="&&_ucv_&j and &eventtype. &&_eb_&i";
          %end;
          %do j=1 %to &_nexpND;
             _expND_&j._&i=&&_expND_&j*(outcometype=&&_eb_&i);
           label  _expND_&j._&i="exposure &&_expND_&j and &eventtype. &&_eb_&i";
          %end;
          %do j=1 %to &_nexpD;
              %do k=1 %to &&_nexpD_&j;
                   _expD_&j._&k._&i=&&_expD_&j._&k.*(outcometype=&&_eb_&i);
                  label _expD_&j._&k._&i="exposure &&_expD_&j._&k. and &eventtype. &&_eb_&i";
                 %end;
             %end;
       %end;

   *variables for pair-wise LRT of heterogeneity test;
    %do j=1 %to &_nexpND;
    %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
            _expND_&j._&i._vs_&j._&k.= &&_expND_&j*(outcometype=&&_eb_&i|outcometype=&&_eb_&k);
        %end;
    %end;
    %end;

    %do j=1 %to &_nexpD;
    %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
             %do m=1 %to &&_nexpD_&j;
               _expD_&j._&m._&i._vs_&j._&m._&k.=&&_expD_&j._&m.*(outcometype=&&_eb_&i|outcometype=&&_eb_&k);
             %end;
        %end;
    %end;
    %end;
run;
%end;



%else %if &augmented=YES %then %do;
data newdatname;
    set _tmp_;
    where time ne .  and censoring ne . and outcometype ne . ;

      %do i=1 %to &_neb_;
          %do j=1 %to &_nexpND;
             _expND_&j._&i=&&_expND_&j._&i..;
           label  _expND_&j._&i="exposure &&_expND_&j._&i.. and &eventtype. &&_eb_&i";
          %end;
          %do j=1 %to &_nexpD;
              %do k=1 %to &&_nexpD_&j;
                   _expD_&j._&k._&i=&&_expD_&j._&k._&i.;
                  label _expD_&j._&k._&i="exposure &&_expD_&j._&k._&i.. and &eventtype. &&_eb_&i";
                 %end;
             %end;
       %end;

*variables for pair-wise LRT of heterogeneity test;
   %do j=1 %to &_nexpND;
       %do i=1 %to &_neb_;
           if outcometype=&i then _expND_&j=&&_expND_&j._&i..;
       %end;
       rename _expND_&j=&&_expND_&j;
   %end;

   %do j=1 %to &_nexpD;
      %do k=1 %to &&_nexpD_&j;
          %do i=1 %to &_neb_;
             if outcometype=&i then _expD_&j._&k=&&_expD_&j._&k._&i..;
          %end;
      rename _expD_&j._&k=&&_expD_&j._&k..;

     %end;
   %end;

    %do j=1 %to &_nexpND;
    %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
            _expND_&j._&i._vs_&j._&k.= _expND_&j*(outcometype=&&_eb_&i|outcometype=&&_eb_&k);
        %end;
    %end;
    %end;

    %do j=1 %to &_nexpD;
    %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
             %do m=1 %to &&_nexpD_&j;
               _expD_&j._&m._&i._vs_&j._&m._&k.=_expD_&j._&m.*(outcometype=&&_eb_&i|outcometype=&&_eb_&k);
             %end;
        %end;
    %end;
    %end;
run;

%end;



ods listing close;

proc phreg data=newdatname outest=LL %if "&covs" eq "YES" %then %do; covs %end; nosummary;
        model (entrytime,time)*censoring(0)=

        %do j=1 %to &_nexpND;
          %do i=1 %to &_neb_;
             _expND_&j._&i
            %end;
        %end;
        %do j=1 %to &_nexpD;
             %do k=1 %to &&_nexpD_&j;
                  %do i=1 %to &_neb_;
                       _expD_&j._&k._&i
                   %end;
               %end;
         %end;

%if "&augmented" eq "NO" %then %do;
            %do j=1 %to &_nunconstrvar;
               %do i=1 %to &_neb_;
                _ucv_&j._&i
            %end;
         %end;
%end;

%else %if "&augmented" eq "YES" %then %do;
    &unconstrvar
%end;

      &constrvar / covb  %if "&studydesign" eq "MCACO" | "&studydesign" eq "CACO" %then %do; ties=discrete %end; ;
     %if "&studydesign" eq "COHORT" | "&studydesign" eq "CACO"  %then %do;  strata outcometype &stratavar; %end;
     %if "&studydesign" eq "MCACO" %then %do;   strata &matchid; %end;


/*Wald heterogeneity test*/
%if "&wald" eq "YES" %then %do;

%do j=1 %to &_nexpND;
*---global heterogeneity test;
    &&_expND_&j.._all: test
            %do i=1 %to %eval(&_neb_-1);
               _expND_&j._&i=
            %end;
            _expND_&j._&_neb_;
*---pairwise heterogeneity test;
    %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
            &&_expND_&j.._&i._vs_&&_expND_&j.._&k.: test _expND_&j._&i = _expND_&j._&k;
        %end;
    %end;
%end;


%do j=1 %to &_nexpD;
*---global & level-wise heterogeneity test;
     dummy&j._all: test
        %do k=1 %to %eval(&&_nexpD_&j-1);
           %do i=1 %to %eval(&_neb_-1);
              _expD_&j._&k._&i=
           %end;
            _expD_&j._&k._&_neb_,
        %end;
           %do i=1 %to %eval(&_neb_-1);
            _expD_&j._&&_nexpD_&j.._&i.=
           %end;
             _expD_&j._&&_nexpD_&j.._&_neb_.;
*---pairwise & level-wise heterogeneity test ;
    %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
            dummy&j._&i._vs_dummy&j._&k.: test
                %do m=1 %to %eval(&&_nexpD_&j-1);
                   _expD_&j._&m._&i = _expD_&j._&m._&k,
                 %end;
                   _expD_&j._&&_nexpD_&j.._&i = _expD_&j._&&_nexpD_&j.._&k;
        %end;
	%end;
*---global & level-specific heterogeneity test;
     %do m=1 %to &&_nexpD_&j;
        dummy&j._&m: test
             %do i=1 %to %eval(&_neb_-1);
                    _expD_&j._&m._&i=
             %end;
                  _expD_&j._&m._&_neb_;
*---pairwise & level-specific heterogeneity test ;
     %do i=1 %to %eval(&_neb_-1);
        %do k=%eval(&i+1) %to &_neb_;
		        dummy&j._&m._&i._vs_dummy&j._&m._&k.: test
                  _expD_&j._&m._&i = _expD_&j._&m._&k;
          %end;
      %end;
     %end;
%end;

%end;  /*---end of Wald=yes*/

ods output ConvergenceStatus=convstat FitStatistics=fitstat ModelInfo=modelinfo
           GlobalTests=globaltest ParameterEstimates=&paramest
           CovB=&covest
           %if "&wald" eq "YES" %then %do; TestStmts=&heterotest._WT %end; ;
run;


/********* LRT for heterogeneity test *********/
data &heterotest.;
    stop;

%do jj=1 %to &_nexpND;
  %LRT(di=0);
%end;

%do jj=1 %to &_nexpD;
  %do lvl=0 %to &&_nexpD_&jj;  /*level-wise, level-specific*/
     %LRT(di=1);
  %end;
%end;

/******************** OUTPUT *********************/
ods listing;

/** check for model convergence**/

data _null_;
    set convstat;
    retain nonconv 0;
    if status ne 0 then nonconv=1;
    call symput ('noconv', trim(left(nonconv)));
run;

%if &noconv eq 1 %then %do;
    ods listing;
    data _null_;
        put "ERR""OR in macro run:  model did not converge.";
        file print;
        put "ERR""OR in macro run:  model did not converge.";
    run;
    ods listing close;
    %end;
%if &noconv eq 1 %then %goto qphreg;

/** model info **/
data modelinfo;
    set modelinfo;
    if upcase(description) eq 'TIES HANDLING' then call symput ('tiehandle', cValue);
run;

/***   Number of observations and events  ***/
%if &studydesign eq COHORT %then %do;
proc sort data=&data;
    by &id;
run;
data &data._tmp;
    set &data;
    retain idcount 0;
    by &id;
    if first.&id then idcount=1;
    else idcount=idcount+1;
    if idcount=1;
run;

proc sql noprint;
    select count(*) into :nobs from &data._tmp;
quit;

title1 "Running on data set %upcase(&data), Read &nobs observations";
title2 "Tie handling: %upcase(&tiehandle) ";
%if %length(&eventtypelabel) ne 0 %then %do;
title3 "%upcase(&eventtype): &eventtypelabel";
%end;

proc freq data=newdatname noprint;
tables outcometype/out=outcometype_tmp;
where censoring=1;
run;
proc print data=outcometype_tmp noobs label;
title4 "Number of cases in each outcome type";
    var outcometype count;
	label outcometype="&eventtype.";
run;
title4;
title3;
title2;
%end;


%if  &studydesign eq CACO %then %do;
/** number of observations **/
proc sql noprint;
    select count(*) into :nobs from &data.;
quit;

title1 "Running on data set %upcase(&data), Read &nobs observations";
%end;

%if  &studydesign eq MCACO %then %do;
/** number of matched set **/
    proc sort data=&data.;
        by &matchid;
run;
data &data._tmp;
    set &data;
    retain midcount 0;
    by &matchid;
    if first.&matchid then midcount=1;
    else midcount=midcount+1;
    if midcount=1;
run;
proc sql noprint;
    select count(*) into :nobs from &data._tmp;
    quit;

title1 "Running on data set %upcase(&data), Read &nobs matched pairs";

%end;

%if &studydesign eq CACO | &studydesign eq MCACO %then %do;

proc freq data=&data noprint;
table &eventtype/out=outcometype_tmp;
run;

title3 "Number of controls and cases in each outcome type";
%if %length(&eventtypelabel) ne 0 %then %do;
title4 "%upcase(&eventtype): &eventtypelabel";
%end;
proc print data=outcometype_tmp noobs label;
    var &eventtype count;
run;
title4;
title3;
%end;



/** model convergence**/

proc print data=convstat noobs label;
title3 "Convergence Status";
    var reason;
run;
title3;

/** Model fit **/
proc print data=fitstat noobs label;
    title3 "Model Fit Statistics";
run;
title3;

/** Global Test**/
proc print data=globaltest noobs label;
    title3 "Testing Global Null Hypothesis: BETA=0";
run;
    title3;

/** MLE **/
data &paramest;
    set &paramest;
    _HR=exp(estimate);
    _HRlowerCL=exp(estimate-1.96*stderr);
    _HRupperCL=exp(estimate+1.96*stderr);
run;
proc print data=&paramest noobs label;
    title3 "Analysis of Maximum Likelihood Estimates";
    var label df estimate stderr _HR _HRlowerCL _HRupperCL probchisq parameter;
    label _HRlowerCL="lowerCL" _HRupperCL="upperCL" probchisq="Pvalue"
        %if &studydesign eq CACO %then %do; _HR="OddsRatio" %end;
		                                         %else %do; _HR="HazardRatio" %end;
        ;
run;
title3;

/** Covariance matrix estimates**/
%if &covout eq YES %then %do;
proc print data=&covest L;
title3 "Estimated Covariance matrix";
run;
title3;
%end;

/** Heterogeneity tests **/

proc print data=&heterotest. noobs label;
title3 "Heterogeneity Tests (Likelihood ratio test)";
var label df P_value;
label label="Label" df="DF" P_value="Pvalue";
run;
title3;

%if &Wald eq YES %then %do;
data &heterotest._WT;
	length label2 $64.;
    set &heterotest._WT;
    %do j=1 %to &_nexpND;
        if label="&&_expND_&j.._all" then do; label2="All: &&_expND_&j.."; end;
        %do i=1 %to %eval(&_neb_-1);
          %do k=%eval(&i+1) %to &_neb_;
              if label="&&_expND_&j.._&i._vs_&&_expND_&j.._&k." then do;
                  label2="Pairwise &i. vs &k.: &&_expND_&j.."; end;
                  %end;
              %end;
          %end;
      %do j=1 %to &_nexpD;
        if label="dummy&j._all" then do; label2="All: &&_expD_&j"; end;
	    %do m=1 %to &&_nexpD_&j;
	      if label="dummy&j._&m" then do; label2="All: &&_expD_&j._&m"; end;
	    %end;
       %do i=1 %to %eval(&_neb_-1);
          %do k=%eval(&i+1) %to &_neb_;
              if label="dummy&j._&i._vs_dummy&j._&k." then do;
                  label2="Pair-wise &i. vs &k.: &&_expD_&j.."; end;
			 %do m=1 %to &&_nexpD_&j;
			 if label="dummy&j._&m._&i._vs_dummy&j._&m._&k." then do;
			       label2="Pairwise &i. vs &k.: &&_expD_&j._&m";end;
             %end;
          %end;
      %end;
    %end;
run;

proc print data=&heterotest._WT noobs label;
        title3 "Heterogeneity Tests (Wald test)";
        var  label2 df probchisq ;
        label label2="Label" df="DF" probchisq="Pvalue";
run;

title3;
title1;
%end;

%end;  *--- end for analysis by PROC PHREG;



/*
%qphreg:
    %if &noconv eq 1 %then %goto qsubtype;
*/

*-------------- PROC LOGISTIC (case-case study and unmatced case-control study) -------------------------;
%if &studydesign eq CACA | (&studydesign eq CACO & &conditional eq NO) %then %do;

data newdatname;
    set &data;
    outcometype=&eventtype;
run;


 /* get list of values of outcometype */
     proc sort data=newdatname;  by outcometype;  run;
     proc means noprint data=newdatname;  var outcometype;
         output  out=_expblist_  mean=m_outcometype;
         by outcometype;
         where outcometype ne . ;
     run;

     data _expblist_;
        set _expblist_  end=_end_;
        call symput('_eb_'||trim(left(_n_)), trim(left(m_outcometype)));
        if _end_ then call symput ('_neb_', trim(left(_n_)));
      run;


%if &studydesign eq CACO %then %do; %let reftype=0; %end;

ods listing close;
proc logistic data=newdatname outest=LL;
    model outcometype(ref="&reftype")=&exposureND &exposureD_ &unconstrvar /link=glogit covb;

    %if &studydesign eq CACA %then %do;
        %do j=1 %to &_nexpND;
*---global heterogeneity test;
            &&_expND_&j.._all: test
                %if &reftype eq 1 %then %do; &&_expND_&j.._2 %end;
                %else %do; &&_expND_&j.._1 %end;
                    %do i=3 %to &_neb_;
                        %if &i ne &reftype %then %do; ,&&_expND_&j.._&i %end;
                    %end;
                 ;
*---pairwise heterogeneity test;
            %do i=1 %to &_neb_;
                %if &i ne &reftype %then %do; &&_expND_&j.._&reftype._vs_&&_expND_&j.._&i.: test &&_expND_&j.._&i; %end;
            %end;
            %do i=1 %to %eval(&_neb_-1);
                %do k=%eval(&i+1) %to &_neb_;
                    %if &i ne &reftype & &k ne &reftype %then %do; &&_expND_&j.._&i._vs_&&_expND_&j.._&k.: test &&_expND_&j.._&i = &&_expND_&j.._&k; %end;
                %end;
            %end;
        %end;

       %do j=1 %to &_nexpD;
*---global & level-wise heterogeneity test;
          dummy&j._all: test
              %if &reftype eq 1 %then %do;
                &&_expD_&j._1._2
               %do k=2 %to &&_nexpD_&j;
                   , &&_expD_&j._&k.._2
               %end;
               %end;
               %else %do;
                   &&_expD_&j._1._1
                 %do k=2 %to &&_nexpD_&j;
                   , &&_expD_&j._&k.._1
                 %end;
               %end;
                 %do i=3 %to &_neb_;
                    %if &i ne &reftype %then %do;
                        %do k=1 %to &&_nexpD_&j;
                            , &&_expD_&j._&k.._&i.
                               %end;
                           %end;
                      %end;
                  ;
*---pairwise & level-wise heterogeneity test;
          %do i=1 %to &_neb_;
             %if &i ne &reftype %then %do;
                   dummy&j._&reftype._vs_dummy&j._&i.: test &&_expD_&j._1._&i
                       %do m=2 %to &&_nexpD_&j; ,&&_expD_&j._&m.._&i. %end; ;
                  %end;
              %end;
          %do i=1 %to %eval(&_neb_-1);
              %do k=%eval(&i+1) %to &_neb_;
                  %if &i ne &reftype & k ne &reftype %then %do;
                      dummy&j._&i._vs_dummy&j._&k.: test &&_expD_&j._1._&i=&&_expD_&j._1._&k
                          %do m=2 %to &&_nexpD_&j; ,&&_expD_&j._&m.._&i=&&_expD_&j._&m.._&k %end; ;
                      %end;
                  %end;
              %end;

*---global & level-specific heterogeneity test;
		%do m=1 %to &&_nexpD_&j;
		dummy&j._&m: test
              %if &reftype eq 1 %then %do;
                &&_expD_&j._&m.._2
               %do i=3 %to &_neb_;
                   , &&_expD_&j._&m.._&i.
               %end;
               %end;
               %else %do;
                   &&_expD_&j._&m.._1
                 %do i=2 %to &_neb_;
				 %if &i ne &reftype %then %do;
                   , &&_expD_&j._&m.._&i
                 %end;
				 %end;
				 %end;
               ;
*---pair-wise & level-specific heterogeneity test;
          %do i=1 %to &_neb_;
             %if &i ne &reftype %then %do;
                   dummy&j._&m._&reftype._vs_dummy&j._&m._&i.: test &&_expD_&j._&m.._&i;
                    %end;
                  %end;
          %do i=1 %to %eval(&_neb_-1);
              %do k=%eval(&i+1) %to &_neb_;
                  %if &i ne &reftype & k ne &reftype %then %do;
                      dummy&j._&m._&i._vs_dummy&j._&m._&k.: test &&_expD_&j._&m.._&i=&&_expD_&j._&m.._&k;
                      %end;
                  %end;
              %end;
          %end;

     %end;

    %end;  *---end for CACA;



 %if &studydesign eq CACO %then %do;
 %do j=1 %to &_nexpND;
*--global heterogeneity test;
            &&_expND_&j.._all: test
                %do i=1 %to %eval(&_neb_-2);
            &&_expND_&j.._&i=
                %end;
            &&_expND_&j.._%eval(&_neb_-1);
*---pairwise heterogeneity test;
            %do i=1 %to %eval(&_neb_-2);
                %do k=%eval(&i+1) %to %eval(&_neb_-1);
                    &&_expND_&j.._&i._vs_&&_expND_&j.._&k.: test &&_expND_&j.._&i = &&_expND_&j.._&k;
                %end;
            %end;
        %end;

     %do j=1 %to &_nexpD;
*--global & level-wise heterogeneity test;
         dummy&j._all: test
         %do i=1 %to %eval(&_neb_-2);
            &&_expD_&j._1._&i.=
           %end;
            &&_expD_&j._1._%eval(&_neb_-1),
        %do k=2 %to &&_nexpD_&j;
           %do i=1 %to %eval(&_neb_-2);
              &&_expD_&j._&k.._&i=
           %end;
            %if &k ne &&_nexpD_&j %then %do; &&_expD_&j._&k.._%eval(&_neb_-1), %end;
                %else %do; &&_expD_&j._&k.._%eval(&_neb_-1); %end;
        %end;
*---pairwise & level-wise heterogeneity test;
    %do i=1 %to %eval(&_neb_-2);
        %do k=%eval(&i+1) %to %eval(&_neb_-1);
            dummy&j._&i._vs_dummy&j._&k.: test
                &&_expD_&j._1._&i = &&_expD_&j._1._&k,
                %do m=2 %to &&_nexpD_&j;
            %if &m ne &&_nexpD_&j %then %do; &&_expD_&j._&m.._&i = &&_expD_&j._&m.._&k, %end;
                %else %do; &&_expD_&j._&m.._&i = &&_expD_&j._&m.._&k; %end;
               %end;
        %end;
		%end;
*--global & level-specific heterogeneity test;
   %do m=1 %to &&_nexpD_&j;
   dummy&j._&m: test
         %do i=1 %to %eval(&_neb_-2);
            &&_expD_&j._&m.._&i.=
          %end;
             &&_expD_&j._&m.._%eval(&_neb_-1);

*---pairwise & level-specific heterogeneity test;
   %do i=1 %to %eval(&_neb_-2);
        %do k=%eval(&i+1) %to %eval(&_neb_-1);
            dummy&j._&m._&i._vs_dummy&j._&m._&k.: test
                &&_expD_&j._&m.._&i = &&_expD_&j._&m.._&k;
        %end;
   %end;
   %end;

    %end; *j;
%end;  *--- end of CACO;




    ods output ConvergenceStatus=convstat FitStatistics=fitstat ModelInfo=modelinfo ResponseProfile=resprof
               ParameterEstimates=&paramest TestStmts=&heterotest Type3=type3 GlobalTests=globaltest Nobs=nobs
               CovB=&covest;
run;


/******************** OUTPUT ***************************/

ods listing;
options nodate;

/** check for model convergence**/
data _null_;
    set convstat;
    retain nonconv 0;
    if status ne 0 then nonconv=1;
    call symput ('noconv', trim(left(nonconv)));
run;

%if &noconv eq 1 %then %do;
    data _null_;
        put "ERR""OR in macro run:  model did not converge.";
        file print;
        put "ERR""OR in macro run:  model did not converge.";
    run;
    %end;
%if &noconv eq 1 %then %goto qlogit;

/** model info **/
data modelinfo;
    set modelinfo;
    if upcase(description) eq 'MODEL' then call symput ('model', Value);
run;

/** number of observations **/
data nobs;
    set nobs;
    if upcase(Label) eq 'NUMBER OF OBSERVATIONS USED' then call symput ('nobs', N);
run;

title1 "Running on data set %upcase(&data), Read &nobs   observations";
title2 "Model: %upcase(&model.)";
%if %length(&eventtypelabel) ne 0 %then %do;
title3 "%upcase(&eventtype): &eventtypelabel";
%end;

proc print data=resprof label noobs;
    %if &studydesign eq CACA %then %do; title4 "Number of cases in each outcome type"; %end;
        %else %do; title3 "Number of controls and cases in each outcome type"; %end;
    var outcome count;
	label outcome="&eventtype.";
run;
title4;
title3;
title2;

/** model conbergence **/
proc print data=convstat noobs label;
 title3 "Convergence Status";
var reason;
run;
title3;

/** Model fit **/
proc print data=fitstat noobs label;
    title3 "Model Fit Statistics";
run;
title3;

/** Global Test **/
proc print data=globaltest noobs label;
    title3 "Testing Global Null Hypothesis: BETA=0";
run;
title3;

/** Type 3 analysis **/
proc print data=type3 noobs label;
    title3 "Type 3 Analysis of Effects";
run;
title3 ;


/** MLE **/
data &paramest;
    set &paramest;
    _oddsratio=exp(estimate);
    _lowerCL=exp(estimate-1.96*stderr);
    _upperCL=exp(estimate+1.96*stderr);
run;

proc print data=&paramest noobs L;
    title3 'Analysis of Maximum Likelihood Estimates';
    var variable response df estimate stderr _oddsratio _lowerCL _upperCL probchisq;
    label _oddsratio="OddsRatio" probchisq="Pvalue" _lowerCL="lowerCL" _upperCL="upperCL" response="&eventtype";
run;
title3;

/** Covariance matrix estimates**/
%if &covout eq YES %then %do;
proc print data=&covest L;
title3 "Estimated Covariance matrix";
run;
title3;
%end;

data &heterotest;
	length label2 $64.;
   set &heterotest;
    %do j=1 %to &_nexpND;
        if label="&&_expND_&j.._all" then do; label2="All: &&_expND_&j.."; end;
        %do i=1 %to %eval(&_neb_-1);
          %do k=%eval(&i+1) %to &_neb_;
              if label="&&_expND_&j.._&i._vs_&&_expND_&j.._&k." then do;
                  label2="Pairwise &i. vs &k.: &&_expND_&j.."; end;
                  %end;
              %end;
          %end;
      %do j=1 %to &_nexpD;
        if label="dummy&j._all" then do; label2="All: &&_expD_&j"; end;
	    %do m=1 %to &&_nexpD_&j;
	      if label="dummy&j._&m" then do; label2="All: &&_expD_&j._&m"; end;
	    %end;
       %do i=1 %to %eval(&_neb_-1);
          %do k=%eval(&i+1) %to &_neb_;
              if label="dummy&j._&i._vs_dummy&j._&k." then do;
                  label2="Pairwise &i. vs &k.: &&_expD_&j.."; end;
			 %do m=1 %to &&_nexpD_&j;
			 if label="dummy&j._&m._&i._vs_dummy&j._&m._&k." then do;
			       label2="Pairwise &i. vs &k.: &&_expD_&j._&m";end;
             %end;
          %end;
      %end;
    %end;

run;

proc print data=&heterotest L noobs;
    title3 'Heterogeneity Tests (Wald test)';
    var  label2 df probchisq ;
    label label2="Label" df="DF" probchisq="Pvalue";
run;
title3;
title1;



%qlogit:
    %if &noconv eq 1 %then %goto qsubtype;


%end;  *--- end for CASE-CASE study and CASE-CONTROL study;



%qsubtype:
data _null_;
     put 'The macro will stop.';
     file print;
     put 'The macro will stop.';
run;
quit;

/*%out: quit;*/

options notes obs=max formdlim="&_fdl";

%mend subtype;



%macro LRT(di=);
proc phreg data=newdatname outest=LLG %if "&covs" eq "YES" %then %do; covs %end;  nosummary;
        model (entrytime,time)*censoring(0)=
%if &di=0 %then %do;
        %do j=1 %to &_nexpND;
        %if &j=&jj %then %do;
            &&_expND_&j
            %end;
        %else %do;
          %do i=1 %to &_neb_;
             _expND_&j._&i
            %end;
        %end;
        %end;
        %do j=1 %to &_nexpD;
             %do k=1 %to &&_nexpD_&j;
                  %do i=1 %to &_neb_;
                       _expD_&j._&k._&i
                   %end;
               %end;
         %end;
%end;

%else %if &di=1 %then %do;

          %do j=1 %to &_nexpND;
            %do i=1 %to &_neb_;
             _expND_&j._&i
            %end;
         %end;
    %if &lvl=0 %then %do;
         %do j=1 %to &_nexpD;
             %if &j=&jj %then %do;
                &&_expD_&j
              %end;
             %else %do;
             %do k=1 %to &&_nexpD_&j;
                  %do i=1 %to &_neb_;
                       _expD_&j._&k._&i
                   %end;
             %end;
             %end;
         %end;
     %end;

     %else %if &lvl ne 0 %then %do;
         %do j=1 %to &_nexpD;
           %if &j=&jj %then %do;
               &&_expD_&j._&lvl
               %do k=1 %to &&_nexpD_&j;
                 %if &k ne &lvl %then %do;
                     %do i=1 %to &_neb_; _expD_&j._&k._&i %end;
                 %end;
             %end;
             %end;
            %else %do;
             %do k=1 %to &&_nexpD_&j;
                  %do i=1 %to &_neb_;
                       _expD_&j._&k._&i
                   %end;
               %end;
			   %end;

            %end;
         %end;
%end;


%if "&augmented" eq "NO" %then %do;
            %do j=1 %to &_nunconstrvar;
               %do i=1 %to &_neb_;
                _ucv_&j._&i
            %end;
         %end;
%end;
%else %if "&augmented" eq "YES"  %then %do;
    &unconstrvar
%end;



     &constrvar %if "&studydesign" eq "MCACO" | "&studydesign" eq "CACO" %then %do; /ties=discrete %end; ;
     %if "&studydesign" eq "COHORT" | "&studydesign" eq "CACO"  %then %do;  strata outcometype &stratavar; %end;
     %if "&studydesign" eq "MCACO" %then %do;   strata &matchid; %end;


run;

data Glrt;
    length label $64.;
    merge LL(keep=_LNLIKE_ _TYPE_ rename=(_LNLIKE_=ll1) where=(_TYPE_="PARMS"))
          LLG(keep=_LNLIKE_ _TYPE_ rename=(_LNLIKE_=ll0) where=(_TYPE_="PARMS"));
    %if &di=0 %then %do;
    label="All: &&_expND_&jj..";
    df=%eval(&_neb_-1);
    %end;
    %else %if &di=1 %then %do;
        %if &lvl=0 %then %do;
          label="All: &&_expD_&jj";
          df=%eval((&_neb_-1)*&&_nexpD_&jj);
          %end;
        %else %if &lvl ne 0 %then %do;
            label="All: &&_expD_&jj._&lvl";
            df=%eval(&_neb_-1);
         %end;
    %end;

    chisq=2*(ll1-ll0);
    P_value=1-probchi(chisq,df);
run;


data &heterotest.;
    set &heterotest. Glrt;
run;

data Glrt;
run;

/** pair-wise test **/

%do ii=1 %to %eval(&_neb_-1);
    %do kk=%eval(&ii+1) %to &_neb_;


proc phreg data=newdatname outest=LLP %if "&covs" eq "YES" %then %do; covs %end; nosummary;
        model (entrytime,time)*censoring(0)=

%if &di=0 %then %do;
        %do j=1 %to &_nexpND;
          %if &j=&jj  %then %do;
            _expND_&j._&ii._vs_&j._&kk.
             %do i=1 %to &_neb_;
               %if (&i ne &ii) & (&i ne &kk) %then %do;
                   _expND_&jj._&i
               %end;
             %end;
          %end;
          %else %do;
            %do i=1 %to &_neb_;
              _expND_&j._&i
            %end;
          %end;
        %end;
        %do j=1 %to &_nexpD;
             %do k=1 %to &&_nexpD_&j;
                  %do i=1 %to &_neb_;
                       _expD_&j._&k._&i
                   %end;
               %end;
         %end;
%end;

%else %if &di=1 %then %do;
        %do j=1 %to &_nexpND;
          %do i=1 %to &_neb_;
             _expND_&j._&i
          %end;
        %end;

        %if &lvl=0 %then %do;
         %do j=1 %to &_nexpD;
             %if &j=&jj %then %do;
                 %do m=1 %to &&_nexpD_&j;
                   _expD_&j._&m._&ii._vs_&j._&m._&kk.
                   %do i=1 %to &_neb_;
                     %if (&i ne &ii) & (&i ne &kk) %then %do;
                       _expD_&j._&m._&i
                      %end;
                   %end;
                 %end;
              %end;
              %else %do;
                  %do m=1 %to &&_nexpD_&j;
                  %do i=1 %to &_neb_;
                       _expD_&j._&m._&i
                   %end;
                   %end;
              %end;
           %end;
		 %end;

        %else %if &lvl ne 0 %then %do;
            %do j=1 %to &_nexpD;
                %if &j=&jj %then %do;
                    _expD_&j._&lvl._&ii._vs_&j._&lvl._&kk.
                    %do m=1 %to &&_nexpD_&j;
					  %if &m=&lvl %then %do;
					  %do i=1 %to &_neb_;
					    %if (&i ne &ii) & (&i ne &kk) %then %do;
                             _expD_&j._&m._&i
                        %end;
						%end;
						%end;
                      %else %if &m ne &lvl %then %do;
                        %do i=1 %to &_neb_;
                             _expD_&j._&m._&i
                         %end;
                        %end;
                   %end;
                %end;
                %else %do;
                    %do m=1 %to &&_nexpD_&j;
                      %do i=1 %to &_neb_;
                        _expD_&j._&m._&i
                      %end;
                    %end;
                %end;
             %end;
      %end;
%end;

%if "&augmented" eq "NO"  %then %do;
         %do j=1 %to &_nunconstrvar;
               %do i=1 %to &_neb_;
                _ucv_&j._&i
               %end;
         %end;
%end;

%else %if "&augmented" eq "YES"  %then %do;
    &unconstrvar
%end;


      &constrvar %if "&studydesign" eq "MCACO" | "&studydesign" eq "CACO" %then %do; /ties=discrete %end; ;
     %if "&studydesign" eq "COHORT" | "&studydesign" eq "CACO"  %then %do;  strata outcometype &stratavar; %end;
     %if "&studydesign" eq "MCACO" %then %do;   strata &matchid; %end;


run;

data Plrt;
    length label $64.;
    merge LL(keep=_LNLIKE_ _TYPE_ rename=(_LNLIKE_=ll1) where=(_TYPE_="PARMS"))
          LLP(keep=_LNLIKE_ _TYPE_ rename=(_LNLIKE_=ll0) where=(_TYPE_="PARMS"));
    %if &di=0 %then %do;
    label="Pairwise &ii. vs &kk.: &&_expND_&jj.. ";
    df=1;
    %end;
    %else %do;
        %if &lvl=0 %then %do;
         label="Pairwise &ii. vs &kk.: &&_expD_&jj";
         df=&&_nexpD_&jj;
        %end;
        %else %do;
         label="Pairwise &ii. vs &kk.: &&_expD_&jj._&lvl";
         df=1;
        %end;
    %end;
    chisq=2*(ll1-ll0);
    P_value=1-probchi(chisq,df);
run;

data &heterotest.;
    set &heterotest. Plrt;
run;

data Plrt;
run;


%end;
%end;

%mend;
