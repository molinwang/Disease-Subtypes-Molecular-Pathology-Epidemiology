

%macro stepmetareg_subtype(data=, model_left_side=, forceinvar=, var_select_from=, eventtype=, _pin=.05, _pout=.05,  
methodtype=ML, weightvar=,maxstep=10,notes=nonotes);
   
  /**************************************************************************************  
   data= name of the data set (required)
   eventtype= name of the subtype variable (required)
   model_left_side= variable name of log relative risk 
   forceinvar=  variables that are always forced into the model(optional)
   var_select_from= list of variables to select from; it should include  the multiple markers (required)
   (nowin, not a macro parameter but a macro variable in the macro to record the selected variables)
   _pin= p value cutoff for adding variable; default is 0.05(optional) 
   _pout= p value cutoff for dropping variable; default is 0.05(optional)
   methodtype= if we want to specify the method= in the proc mixed. Default is ML(optional)
   weightvar= it should be the inverse variance of the log relative risk estimates in the subtype analysis (optional)
   maxstep= the maximum steps of the variables selection to control the selection loop problem
            default is 10;(optional),
   notes= NOTES/NONOTES, NOTES if we want to list the SAS log notes, which would include SAS log notes from every run of 
proc mixed, in the saslog file, in addition to the results of a step-wise variable selection; default is NONOTES(optional)



Here is the proc mixed example that can be handle by this macro:

ods output SolutionF=fixest;
proc mixed data=pecomp asycov method=ml;
class eventtype;
model Estimate = cimphighf msinf brafmtf krasmutf ptgs2f/ s covb;
random eventtype;
repeated;
weight w ;
parms (0) ( 1)/ eqcons= 1,2;
run;

data fixest;
set fixest;
chisq=estimate**2/stderr**2;
pchi=1-probchi(chisq,1);
run;

**************************************************************************************/


%let notes=%upcase(&notes);
%let methodtype=%upcase(&methodtype);

options &notes;

%if %length(&var_select_from) eq 0 %then %goto dfinish2;
   
%global finalnowin; 

%let nowin=;
   
%local dndone updone _nstep _fin_  _fdl _nt i _nvni_ _nvnami_
_nout_  _nno_ j _nin_ _nout_ _nvno_ _nvnamo_ _nodel;
 
/** getoption is a system function to get value of formdlim and notes **/
%let _fdl = %sysfunc(getoption(formdlim));
%let _nt = %sysfunc(getoption(notes));
   

/*                                                                            ;
* This macro was developed by Carrie Wager,Programmer,Channing Laboratory 1990;
* Modified AMcD 1993, e hertzmark 1994 and L Chen 1996;
*                                                                            ;
* modified by Biling, 12/04/2013 
*/

%macro numargs_new(arg);
   %if %quote(&arg)= %then %do;
        0
   %end;
   %else %do;
     %let nforvar=1;
     %do %until (%qscan(%quote(&arg), %eval(&nforvar), %str( ))=%str()); 
        %let nforvar=%eval(&nforvar+1);
        %end;
	%eval(&nforvar-1)
   %end;
   %mend;



%let _nno_ = %numargs_new(&var_select_from);/* number of vbls from which we are selecting */
%do i=1 %to &_nno_;
   %let _instat&i = 0;
   %let _vvn_&i  = %scan(&var_select_from, &i, %str( ));
   %let _vvnn_&i = "&&_vvn_&i";
%end;
   






 
%macro mknowinout;
   /* makes nowin, var_select_from lists */
%let nowin=;  %let var_select_from=;
%do i=1 %to &_nno_;
   %if &&_instat&i eq 1 %then %do;  %let nowin = &nowin &&_vvn_&i ;  %end;
   %else %do;  %let var_select_from = &var_select_from &&_vvn_&i ;  %end;
%end;
%let _nin_ = %numargs_new(&nowin);
%let _nout_ = %numargs_new(&var_select_from);
%mend mknowinout;

%let _nstep = 0;
%let _fin_ = 0 ;
%let updone = 0 ;  %let dndone = 0 ;

data _cuc__;  
   set &data; 
   where &model_left_side ne .;
   %if %length(&forceinvar) ne 0 %then %do;
      %do i = 1 %to %numargs_new(&forceinvar);
	 	if %scan(&forceinvar, &i, %str( )) ne .;
      %end;
   %end;

   %do i = 1 %to &_nno_;  if &&_vvn_&i ne . ;  %end;
   run;
   
 /*********************************************************************/
 /********************************************************************/   
 /** step 1: forward selection one possible var. from var_select_from list  **/
 /*U*/ %up:
 /*U*/ /*********************************************************************/
 /*U*/ /********************************************************************/   
 /*U*/  
 /*U*/ ods listing close;
 /*U*/    
 /*U*/ %if &updone eq 1 and &dndone eq 1 %then %do;  %let _fin_ = 1;  %end;
 /*U*/ %if &_fin_ eq 1 %then %goto mfinish;
 /*U*/       
   
 /*U*/ %mknowinout;
 /*U*/ /* check whether there are any variables with instat=0 */   
 /*U*/ /** if there are no var. on the list to select from **/
 /*U*/ %if &_nout_ eq 0 %then %do;  %let updone = 1 ;  %end;
 /*U*/ %if &updone eq 1 %then %do;
 /*U*/   ods listing;
 /*U*/    data _null_;
 /*U*/     put "Step &_nstep:  no variables to add";  
 /*U*/     file print;  
 /*U*/     put "Step &_nstep:  no variables to add";  
 /*U*/    run;
 /*U*/   ods listing close;
 /*U*/   %end;
 /*U*/  %if &updone=1 %then %goto down;
 /*U*/ *-------------------------------------------------------------------;   
 /*U*/    /* if there are vbls in the possible selection var. list (var_select_from list), 
 /*U*/    /* then add each of them to get loglikelihood difference; then compare with 
 /*U*/    /* the baseline model, i.e., without this variable: if it is <= SLSENTRY
 /*U*/    /* level, the corresponding variable is added to the nowin list. 
		     
 /*U*/   /*  second step: for the model with the newly added var., check each var.
 /*U*/   /*  in the nowin list if it should be deleleted from the model by comparing 
 /*U*/   /*  the model without this var.: if it is > SLSTAY level, then drop it.
 /*U*/   
 /*U*/   /*  continue to do so until there is no more var. to be added or dropped. */
 /*U*/ 
    
    
  /*U*/ %if "&updone" ne "1" %then %do;
  /*U*/    ods listing close;
     
  /*U*/ /** step 1: forward selection one var. with smallest p-value among */
 /*U*/    /* all the vbls with instat=0 **/
 /*U*/    
    
   
 /*U*/    
 /*U*/ ********************************************************************;  
 /*U*/ 
 /*U*/ %do i=1 %to &_nno_;
 /*U*/       ods listing close;
 /*U*/   %if &&_instat&i eq 0 %then %do;
 /*U*/       /* run genmod with this vbl in */


 /*** Biling_mixed ********** first mixed **************************/

 ods listing close;

 /*U*/       proc mixed data=_cuc__ method=&methodtype asycov noclprint;

 /*U*/          class &eventtype;

/*U*/          model &model_left_side = &forceinvar  &nowin &&_vvn_&i/s covb;

 /*U*/         %if %length(&weightvar) ne 0 %then %do;  weight &weightvar;  %end;

               random &eventtype;

			   repeated;

/*U*/          parms (0) (1)/eqcons=1,2;
 /*U*/         ods output SolutionF=fixestup convergencestatus=convstat;
 /*U*/       run;

 			data fixestup&i;
				set fixestup;
				chisq=(estimate**2)/(stderr**2);
				pchi=1-probchi(chisq,1);
				if effect=&&_vvnn_&i;
			run;


			/*U*/       
 /*U*/       data convstat;  set convstat;
 /*U*/       retain noconv 0;
 /*U*/       if status ne 0 then noconv=1;
 /*U*/       call symput('noconv', noconv);
 /*U*/       run;
    
 /*U*/       %if &noconv eq 1 %then %do; 
				data _sc_&i;  pscore&i=.;  run;  
			 %end;
 /*U*/       %else %do;
 /*U*/       	data _sc_&i;  set fixestup&i; pscore&i=pchi; keep pscore&i;  run;
 /*U*/       %end;  /* end of  else part */
 /*U*/    
 /*U*/    %end;  /* end of instat&i eq 0 */
 /*U*/    %else %do;  data _sc_&i;  pscore&i=.;  run;  %end;
 /*U*/ %end;  /* end of loop on i: do i=1 %to &_nno_; */
 /*U*/     


 /*U*/ ods listing;
 /*U*/ %let _nvni_ = ;
 /*U*/ data _sc_;  
 /*U*/    merge  %do i=1 %to &_nno_;  _sc_&i  %end;  ;
 /*U*/    
 /* Biling rev_02: delete the following codes: 
		updone=1;
 */
 /*U*/    minp=1;
 /*U*/    %do i=1 %to &_nno_;
 /*U*/       if . lt pscore&i lt minp then do;
 /*U*/ 	        minp=pscore&i;  nvni=&i;  
 /*U*/          put "step &_nstep vbl &i : "  minp= ;
 /*U*/ 	     end;
 /*U*/    %end;
 /*U*/    call symput('_nvni_', trim(left(nvni)));
 /*U*/ run;

 /*U*/ data _sc_;  set _sc_   ;
 /*U*/   length nvnam $30;
 /*U*/    nvnam="&&_vvn_&_nvni_";
 /*U*/    if . lt  minp lt &_pin then do;
 /*U*/      /* these are the number and name of the potential new vbl */
 /*U*/      updone=0;
 /*U*/      put "Step  &_nstep :  variable  &&_vvn_&_nvni_  added";
 /*U*/      call symput("_instat&_nvni_", 1);
 /*U*/      call symput ('_nvni_', trim(left(nvni)));
 /*U*/      call symput ('_nvnami_', nvnam);
 /*U*/      put '********' nvni nvnam minp ;
 /*U*/    end;
 /*U*/  else do;
 /*U*/     put "Step  &_nstep :   no variable added";
 /*Biling rev_03: add the following codes:*/
 		   updone=1;
 /*U*/  end;
 /*U*/  call symput ('updone', updone);
 /*U*/  run;

 /*U*/ data _sc_;  set _sc_;
 /*U*/  file print;
 /*U*/  if . lt  minp lt &_pin then do;
 /*U*/     /* these are the number and name of the potential new vbl */
 /*U*/     put "Step  &_nstep :  variable &&_vvn_&_nvni_  added";
 /*U*/  end;
 /*U*/  else do;
 /*U*/     put "Step  &_nstep :   no variable added";
 /*U*/  end;
 /*U*/ run;
 /*U*/    

 /*U*/ %mknowinout;



 /*U*/       
 /*U*/    proc datasets nolist;  delete   _sc_ 
 /*U*/      %do i=1 %to &_nno_;  _sc_&i  %end;  ;
 /*U*/    run;
    
 /*U*/ *-------------------------------------------------------------------;
 
/*U*/ data _null_;  
 /*U*/    nstep=&_nstep;  
 /*U*/    nstep=nstep+1;  
 /*U*/    maxstep=&maxstep;
 /*U*/    fin=0;
 /*U*/    if nstep > maxstep then fin=1;
 /*U*/    call symput ("_fin_", fin);
 /*U*/    call symput("_nstep", trim(left(nstep)));
 /*U*/    run;

%end;  /* end of updone ne 1 */

 /*U*/ %if &_fin_ eq 1  %then %goto mfinish;
 /*U*/

 /* Biling rev_06: add the following code*/ 
		%if &updone eq 1 and &dndone eq 1 %then %goto dfinish;

/*U*/ 
/* Biling rev_07: detele %if &_fin_ ne 1  %then %goto down; into the following */
%if &_fin_ ne 1 and &dndone ne 1 %then %goto down;




  /*********************************************************************/
  /********************************************************************/ 
  /** step 2: backward elimination possible var. from NOWIN list  **/  
%down:  
  /*********************************************************************/
  /********************************************************************/   

proc datasets nolist;
delete fixestup;  
run;


 /*D*/    
 /*D*/ /* check whether nowin is null */   
 /*D*/ %if &_nin_ eq 0  %then %do;  
 /*D*/    %let dndone=1;
 /*D*/    ods listing;
 /*D*/    data _null_;
 /*D*/    put "Step &_nstep :    no variables to eliminate";
 /*D*/    file print;
 /*D*/    put "Step &_nstep :    no variables to eliminate";
 /*D*/    run;
 /*D*/    %if &notes ne NOTES %then %do;
 /*D*/       ods listing close;
 /*D*/     %end;
    
 /*D*/ %end;
 
 /*D*/ /** if no more var. in &var_select_from and &nowin, then stop **/
 /*D*/ %if &updone eq 1 and &dndone eq 1 %then %goto dfinish;
    
 /*D*/ /** if there are no var. in &nowin, but do have in &var_select_from, then go to up **/
 /*D*/ %if &_nin_ eq 0 and  &updone ne 1 %then %goto up;
    
 /*D*/ %if &dndone eq 0 and &_nin_ ne 0  %then %do;
 /*D*/    
 /*D*/    ods listing close;
 /*D*/          


       proc mixed data=_cuc__ method=&methodtype asycov noclprint;

          class &eventtype;

          model &model_left_side = &forceinvar  &nowin/s covb;

         %if %length(&weightvar) ne 0 %then %do;  weight &weightvar;  %end;

               random &eventtype;

			   repeated;

          parms (0) (1)/eqcons=1,2;
         ods output SolutionF=fixestdown convergencestatus=convstat;
       run;

 			data fixestdown;
				set fixestdown;
				chisq=(estimate**2)/(stderr**2);
				pchi=1-probchi(chisq,1);
			run;


 /*D*/    data convstat;  
 /*D*/       set convstat;
 /*D*/       retain noconv 0;
 /*D*/       if status ne 0 then noconv=1;
 /*D*/       call symput('noconv', noconv);
 /*D*/    run;
 /*D*/  
 /*D*/    %if &noconv eq 1 %then %do;
 /*D*/       ods listing;
 /*D*/       data _null_;
 /*D*/ 	     put "Step &_nstep:   model with variables &forceinvar &nowin did not converge";
 /*D*/       file print;
 /*D*/       put "Step &_nstep:   model with variables &forceinvar &nowin did not converge";
 /*D*/ 	     run;
 /*D*/       ods listing close;     
 /*D*/    %end; /* end of   %if &noconv eq 1 */      
 /*D*/  
 /*D*/      
 /*D*/ %if &noconv eq 0 %then %do;  /* model converged */   
    
 /*D*/     %let _nodel = 0;

    
 /*D*/    ods listing;    
/*D*/     data names;  length _vn_ $30;
/*D*/     %do i=1 %to &_nno_;
/*D*/        line=&i;  _vn_=&&_vvnn_&i;  output;
/*D*/     %end;
/*D*/     run;
/*D*/     proc sort;  by _vn_;  run;

/*D*/     data fixestdown;  set fixestdown;
/*D*/     length _vn_ $30;  _vn_=effect;
/*D*/     run;
/*D*/     proc sort;  by _vn_;  run;



/*D*/     data fixestdown;  merge names fixestdown;  by _vn_;  if line =. then delete; run;
/*D*/     proc sort data=fixestdown;  by line;  run;


 /*D*/    data fixestdown;  set fixestdown  end=_end_;
 /*D*/    retain maxp 0  nvno   vno;
 /*D*/    length vno $30;
 /*D*/    if pchi gt maxp then do;    
 /*D*/       maxp=pchi;
 /*D*/       vno=_vn_;  nvno=_n_;   
 /*D*/    end;
 /*D*/    if _end_ then do;
 /*D*/       if . lt maxp lt &_pout then do;
 /*D*/            %let _nodel = 1 ;
 /*D*/           put "Step &_nstep :  No variable deleted.";
 /*D*/           file print;
 /*D*/           put "Step &_nstep :  No variable deleted.";
 /*D*/       end;
 /*D*/       else do;
 /*D*/          put "Step &_nstep :  Variable " vno " deleted.";      
 /*D*/          file print;
 /*D*/          put "Step &_nstep :  Variable " vno " deleted.";
 /*D*/          call symput ('nvno', trim(left(nvno)));
 /*D*/          call symput ('_instat'||trim(left(nvno)), 0);
 /*D*/        end;
 /*D*/     end;  /* end of if _end_ */   
 /*D*/     run;
 /*D*/     ods listing close;
 /*D*/ %end;  /* end of noconv eq 0 */


proc datasets nolist;
delete fixestdown names;  
run;

 /*D*/ %if &updone eq 1 and &_nodel eq 1 %then %goto dfinish;
 
 /*D*/ %mknowinout;   
 /*D*/ %if &_nin_ eq 0 %then %do;  %let dndone = 1 ;  %end;
    
 /*D*/    
 /*D*/ data _null_;  nstep=&_nstep;  nstep=nstep+1;  maxstep=&maxstep;
 /*D*/    fin=0;
 /*D*/    if nstep ge maxstep then fin=1;
 /*D*/    call symput ('_fin_', fin);
 /*D*/    call symput ('_nstep', trim(left(nstep)));
 /*D*/    run;
 /*D*/    
 /*D*/ ***********************************************************;
    
    
 /*D*/ %if &_fin_ eq 1 %then %goto mfinish;
 /*D*/ %if &dndone eq 1 and &updone eq 1 %then %goto dfinish;
 /*D*/ %if &dndone eq 0 and &_nodel eq 0 %then %goto down;
 /*D*/ %if  &updone eq 0 %then %goto up;
 /*D*/ %end;  /* end of nowin not null and dndone eq 0*/
    
    
/* Biling rev_09: delete the following codes */
/* %goto up; */

/* Biling rev_10: Move below codes (%mfinish) right before %dfinish2 **/ 

 /*%mfinish:  */
/*data _null_;  */
/*   put "WARNING:  Stepwise procedure stopped because it hit the maximum step number, &maxstep.";*/
/*   file print;*/
/*   put "WARNING:  Stepwise procedure stopped because it hit the maximum step number, &maxstep.";*/
/*   run;*/
/*%goto _end;*/
 

%dfinish:
data _null_;  
   file print;
   put 'stepwise procedure cannot add or delete more variables.';
run;
   

%mknowinout;
%put selectvar=&nowin;
%let finalnowin = &nowin;

ods listing;
ods rtf file="finalselect_mixedresult.rtf"; 
proc mixed data=_cuc__ method=&methodtype asycov noclprint;
            class &eventtype;
            model &model_left_side = &forceinvar  &finalnowin/s covb;

         %if %length(&weightvar) ne 0 %then %do;  weight &weightvar;  %end;

               random &eventtype;

			   repeated;

          parms (0) (1)/eqcons=1,2;
         ods output SolutionF=fixestfinal convergencestatus=convstat;
       run;

 			data fixestfinal;
				set fixestfinal;
				chisq=(estimate**2)/(stderr**2);
				pchi=1-probchi(chisq,1);
				drop DF tValue Probt;
			run;
            
			title "Final model:";
			proc print data=fixestfinal; run;
			title "  ";
ods rtf close;

 
/** add by Biling, 2/20/2014 ***/

ods listing;
ods rtf file="fullvarlist_mixedresult.rtf"; 
proc mixed data=_cuc__ method=&methodtype asycov noclprint;
            class &eventtype;
            model &model_left_side = &forceinvar  &var_select_from/s covb;

         %if %length(&weightvar) ne 0 %then %do;  weight &weightvar;  %end;

               random &eventtype;

			   repeated;

          parms (0) (1)/eqcons=1,2;
         ods output SolutionF=fixestfull convergencestatus=convstat;
       run;

 			data fixestfull;
				set fixestfull;
				chisq=(estimate**2)/(stderr**2);
				pchi=1-probchi(chisq,1);
				drop DF tValue Probt;
			run;
            
			title "full model:";
			proc print data=fixestfull; run;
			title "  ";
ods rtf close;
 
proc datasets nolist;  
   delete _cuc__ fixestfull fixestfinal;  
run;


/***************************************/




%goto _end;

/* Biling rev_15*: change the location */
%mfinish:  
data _null_;  
   put "WARNING:  Stepwise procedure stopped because it hit the maximum step number, &maxstep.";
   file print;
   put "WARNING:  Stepwise procedure stopped because it hit the maximum step number, &maxstep.";
   run;
/* Biling rev_16: change %goto finish into %goto _end */
/*%goto finish;*/
%goto _end;

 
%dfinish2:
data _null_;  
   file print;
   put 'WARNING: You have to at least provide one var. to select from';
   
   run;  

%_end:  quit;
%mend;
